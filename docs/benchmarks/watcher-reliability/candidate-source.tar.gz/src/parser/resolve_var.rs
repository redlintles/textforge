use std::{borrow::Cow, ops::Deref};

use crate::{
    context::execution_context::{GlobalContextMethods, GlobalExecutionContext},
    globals::table::{QuerySource, QueryTarget, SyntaxDef, SyntaxToken, TOKEN_TABLE, TargetValue},
    parser::params::TextForgeParamTypes,
    tokens::{InstructionMethods, instructions::null::Null},
    utils::{
        errors::{TextForgeError, TextForgeErrorCode},
        expr::interpolate,
        regexes::VAR_REF_RE,
    },
};

#[cfg(feature = "bytecode")]
use crate::to_bytecode;
#[derive(Clone, Debug)]
pub enum ValType {
    Literal(TextForgeParamTypes),
    VarRef(String),
}

impl From<String> for ValType {
    fn from(value: String) -> Self {
        ValType::from(value.as_str())
    }
}

impl From<&str> for ValType {
    fn from(value: &str) -> Self {
        match VAR_REF_RE.captures(value) {
            Some(caps) => Self::VarRef(caps[1].to_string()),
            None => Self::Literal(TextForgeParamTypes::String(value.to_string())),
        }
    }
}
impl From<usize> for ValType {
    fn from(value: usize) -> Self {
        Self::Literal(TextForgeParamTypes::Usize(value))
    }
}

impl From<ValType> for TextForgeParamTypes {
    fn from(value: ValType) -> Self {
        match value {
            ValType::Literal(v) => v,
            ValType::VarRef(name) => TextForgeParamTypes::VarRef(name),
        }
    }
}

#[derive(Clone)]
pub struct TokenWrapper {
    params: Vec<ValType>,
    pub token: Box<dyn InstructionMethods>,
}

impl Default for TokenWrapper {
    fn default() -> Self {
        TokenWrapper {
            params: Vec::new(),
            token: Box::new(Null::default()),
        }
    }
}

impl Deref for TokenWrapper {
    type Target = Box<dyn InstructionMethods>;
    fn deref(&self) -> &Self::Target {
        &self.token
    }
}

impl From<Box<dyn InstructionMethods>> for TokenWrapper {
    fn from(value: Box<dyn InstructionMethods>) -> Self {
        let token_params = value
            .get_params()
            .clone()
            .into_iter()
            .map(ValType::Literal)
            .collect::<Vec<ValType>>();
        TokenWrapper {
            params: token_params,
            token: value,
        }
    }
}

impl From<TokenWrapper> for Box<dyn InstructionMethods> {
    fn from(value: TokenWrapper) -> Self {
        value.token
    }
}

impl TokenWrapper {
    pub fn get_params(&self) -> &Vec<ValType> {
        &self.params
    }
    pub fn get_default_token(&self) -> Box<dyn InstructionMethods> {
        self.token.clone()
    }
    pub fn new(token: Box<dyn InstructionMethods>, params: Option<Vec<ValType>>) -> Self {
        match params {
            Some(param_vec) => TokenWrapper {
                params: param_vec,
                token,
            },
            None => {
                let token_params = token
                    .get_params()
                    .clone()
                    .into_iter()
                    .map(ValType::Literal)
                    .collect::<Vec<ValType>>();
                TokenWrapper {
                    params: token_params,
                    token,
                }
            }
        }
    }
    pub fn apply_token<'a>(
        &self,
        input: Cow<'a, str>,
        context: &mut GlobalExecutionContext,
    ) -> Result<Cow<'a, str>, TextForgeError> {
        let parsed_params = ValType::resolve_variables(&self.token, &self.params, &mut *context)?;

        let mut t = self.token.clone();

        t.from_params(&parsed_params)?;

        t.transform(input, Some(context))
    }

    #[cfg(feature = "buffered")]
    pub(crate) fn apply_buffered(
        &self,
        input: crate::api::TextBuffer,
        context: &mut GlobalExecutionContext,
    ) -> Result<crate::api::TextBuffer, TextForgeError> {
        let params = ValType::resolve_variables(&self.token, &self.params, context)?;
        let mut token = self.token.clone();
        token.from_params(&params)?;
        token.transform_buffered(input, Some(context))
    }

    pub fn to_text_line_resolved(
        &self,
        context: &mut GlobalExecutionContext,
    ) -> Result<String, TextForgeError> {
        let parsed_params = ValType::resolve_variables(&self.token, &self.params, &mut *context)?;
        let mut t = self.token.clone();
        t.from_params(&parsed_params)?;

        Ok(t.to_textforge_line().into())
    }

    pub fn to_text_line_unresolved(&self) -> Result<String, TextForgeError> {
        let mut parsed_params = Vec::new();

        for param in self.params.iter() {
            match param {
                ValType::Literal(x) => parsed_params.push(x.clone()),
                ValType::VarRef(var_name) => {
                    parsed_params.push(TextForgeParamTypes::String(format!(
                        "{{{{{}}}}}",
                        var_name.clone()
                    )));
                }
            }
        }

        let mut t = self.token.clone();

        t.from_params(&parsed_params)?;

        Ok(t.to_textforge_line().into())
    }
    #[cfg(feature = "bytecode")]
    pub fn to_bytecode_resolved(
        &self,
        context: &mut GlobalExecutionContext,
    ) -> Result<Vec<u8>, TextForgeError> {
        let parsed_params = ValType::resolve_variables(&self.token, &self.params, &mut *context)?;
        let mut t = self.token.clone();
        t.from_params(&parsed_params)?;

        Ok(t.to_bytecode()?)
    }
    #[cfg(feature = "bytecode")]
    pub fn to_bytecode_unresolved(&self) -> Result<Vec<u8>, TextForgeError> {
        let mut unresolved_params: Vec<TextForgeParamTypes> = Vec::new();
        for val in self.params.iter() {
            match val {
                ValType::Literal(x) => unresolved_params.push(x.clone()),
                ValType::VarRef(name) => {
                    unresolved_params.push(TextForgeParamTypes::VarRef(name.to_string()));
                }
            }
        }

        let result = to_bytecode!(self.get_opcode(), unresolved_params);

        Ok(result)
    }
}

pub fn get_effective_param_types(expected: &[SyntaxDef]) -> Vec<SyntaxToken> {
    expected
        .iter()
        .filter_map(|ip| match ip.token {
            SyntaxToken::Literal(_) => None,
            other => Some(other),
        })
        .collect()
}

impl ValType {
    fn coerce_param(
        value: TextForgeParamTypes,
        expected: SyntaxToken,
        context_label: &str,
    ) -> Result<TextForgeParamTypes, TextForgeError> {
        match (value, expected) {
            (TextForgeParamTypes::String(v), SyntaxToken::String) => {
                Ok(TextForgeParamTypes::String(v))
            }
            (TextForgeParamTypes::Usize(v), SyntaxToken::Usize) => {
                Ok(TextForgeParamTypes::Usize(v))
            }
            (TextForgeParamTypes::Token(v), SyntaxToken::Token) => {
                Ok(TextForgeParamTypes::Token(v))
            }

            // Coerção elástica: string <-> número
            (TextForgeParamTypes::String(s), SyntaxToken::Usize) => s
                .parse::<usize>()
                .map(TextForgeParamTypes::Usize)
                .map_err(|_| {
                    TextForgeError::new(
                        TextForgeErrorCode::IncompatibleTypeError(
                            format!(
                                "'{}' contém \"{}\", que não é um número válido",
                                context_label, s
                            )
                            .into(),
                        ),
                        "resolve_variables()",
                        "",
                    )
                }),
            (TextForgeParamTypes::Usize(n), SyntaxToken::String) => {
                Ok(TextForgeParamTypes::String(n.to_string()))
            }

            // Token não tem conversão sensata a partir de String/Usize, e cobre
            // também o caso degenerado de um TextForgeParamTypes::VarRef não resolvido
            // chegando aqui (não deveria acontecer, mas é um catch-all seguro).
            (_, expected) => Err(TextForgeError::new(
                TextForgeErrorCode::IncompatibleTypeError(
                    format!(
                        "'{}' não pode ser usado como {:?} aqui",
                        context_label, expected
                    )
                    .into(),
                ),
                "resolve_variables()",
                "",
            )),
        }
    }
    fn resolve_variables(
        t: &Box<dyn InstructionMethods>,
        values: &Vec<ValType>,
        context: &mut GlobalExecutionContext,
    ) -> Result<Vec<TextForgeParamTypes>, TextForgeError> {
        let mut result = Vec::new();

        let query_result = TOKEN_TABLE.find((
            QuerySource::Identifier(t.get_string_repr().into()),
            QueryTarget::Syntax,
        ))?;

        let expected_params = get_effective_param_types(
            &(match query_result {
                TargetValue::Syntax(x) => x,
                _ => unreachable!("Unreachable Code"),
            }),
        );

        if values.len() != expected_params.len() {
            return Err(TextForgeError::new(
                TextForgeErrorCode::InvalidParameters("Param count mismatch".into()),
                "resolve_variables",
                format!(
                    "token={}, expected={}, got={}",
                    t.get_string_repr(),
                    expected_params.len(),
                    values.len()
                ),
            ));
        }

        for (i, value) in values.iter().enumerate() {
            match value {
                ValType::Literal(literal) => match (literal, expected_params[i]) {
                    // Único braço que muda: uma string literal passa pela
                    // interpolação antes de virar o parâmetro final. Isso
                    // cobre tanto o caso comum (nenhum {{}}/[[]] presente —
                    // interpolate() devolve a string inalterada pelo
                    // fast-path) quanto strings com N marcadores misturados.
                    (TextForgeParamTypes::String(s), SyntaxToken::String) => {
                        result.push(TextForgeParamTypes::String(interpolate(s, context)?));
                    }

                    (TextForgeParamTypes::Usize(_), SyntaxToken::Usize)
                    | (TextForgeParamTypes::Token(_), SyntaxToken::Token) => {
                        result.push(literal.clone());
                    }

                    _ => {
                        return Err(TextForgeError::new(
                            TextForgeErrorCode::IncompatibleTypeError(
                                "Literal type and required param type are different".into(),
                            ),
                            "resolve_variables()",
                            "",
                        ));
                    }
                },

                ValType::VarRef(name) => {
                    let variable = context.get_var(name)?;

                    let coerced = Self::coerce_param(
                        variable.value.clone().into(),
                        expected_params[i],
                        name,
                    )?;

                    result.push(coerced);
                }
            }
        }

        Ok(result)
    }
}
